SELECT chat_status
FROM chats
WHERE user_id = ?