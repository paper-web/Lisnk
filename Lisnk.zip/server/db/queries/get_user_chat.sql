SELECT chat
FROM chats
WHERE user_id = ?