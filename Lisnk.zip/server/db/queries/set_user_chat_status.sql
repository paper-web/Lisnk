UPDATE chats
SET chat_status = ?
WHERE user_id = ?